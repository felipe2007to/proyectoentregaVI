import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Se corren DOS puertos:
//  - 3000: la página React (el puerto público que se abre en el navegador)
//  - 5000: la API ficticia de json-server (el puerto privado que lee db.json)
// El proxy reenvía lo que empiece por /api al puerto 5000, así la página
// funciona igual en Visual Studio Code y en GitHub Codespaces.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    allowedHosts: true,
    proxy: {
      "/api": {
        target: "http://localhost:5000",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ""),
      },
    },
  },
});
