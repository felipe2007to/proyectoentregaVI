// Una fila de la tabla: muestra los datos de un registro y los botones Editar y Eliminar.
const pesos = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });

// Aplica el formato que indique la columna (por ahora, dinero en pesos)
const mostrar = (valor, formato) => (formato === 'pesos' ? pesos.format(Number(valor) || 0) : valor);

export default function CrudTableRow({ el, columnas, calculados, setDataToEdit, deleteData }) {
  return (
    <tr>
      <th scope="row">{el.id}</th>
      {columnas.map((c) => (
        <td key={c.name}>{mostrar(el[c.name], c.formato)}</td>
      ))}
      {/* Columnas calculadas, por ejemplo Total = cantidad × precio */}
      {calculados.map((c) => (
        <td key={c.label} className="fw-semibold">{mostrar(c.fn(el), c.formato)}</td>
      ))}
      <td className="text-nowrap">
        <button className="btn btn-sm btn-outline-primary me-2" onClick={() => setDataToEdit(el)}>Editar</button>
        <button className="btn btn-sm btn-outline-danger" onClick={() => deleteData(el.id)}>Eliminar</button>
      </td>
    </tr>
  );
}
