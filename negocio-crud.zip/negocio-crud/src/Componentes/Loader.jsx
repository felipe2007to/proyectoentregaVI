// Indicador de carga de Bootstrap (spinner). Se muestra mientras llegan los datos de la API.
export default function Loader() {
  return (
    <div className="d-flex justify-content-center align-items-center gap-2 py-4" role="status">
      <div className="spinner-border text-primary" aria-hidden="true"></div>
      <span>Cargando datos…</span>
    </div>
  );
}
