// CrudAPI: el componente principal del CRUD. Usa useState para guardar los datos y
// useEffect para pedirlos a la API. Sirve para cualquier entidad (productos, clientes, etc.).
import { useEffect, useState } from 'react';
import { helpFetch } from '../helpers/helpFetch.js';
import CrudForm from './CrudForm.jsx';
import CrudTable from './CrudTable.jsx';
import Loader from './Loader.jsx';
import Mensaje from './Mensaje.jsx';

const api = helpFetch();

export default function CrudAPI({ entidad }) {
  const [db, setDb] = useState([]);                 // lista de registros
  const [dataToEdit, setDataToEdit] = useState(null); // registro que se está editando
  const [cargando, setCargando] = useState(true);
  const [aviso, setAviso] = useState(null);         // { tipo, texto }
  const [opciones, setOpciones] = useState({});     // listas para los campos select
  const url = `/${entidad.clave}`;

  // READ: cada vez que cambia la entidad se vuelve a pedir la lista a la API
  useEffect(() => {
    let vigente = true;
    setCargando(true);
    setAviso(null);
    setDataToEdit(null);
    api.get(url).then((res) => {
      if (!vigente) return;
      if (res.err) { setDb([]); setAviso({ tipo: 'danger', texto: res.statusText }); }
      else setDb(res.data);
      setCargando(false);
    });
    return () => { vigente = false; }; // evita actualizar el estado si ya cambió de pestaña
  }, [url]);

  // Algunos campos son listas desplegables que salen de otra tabla (ej. el proveedor de una compra)
  useEffect(() => {
    entidad.campos.filter((c) => c.opcionesDe).forEach((c) => {
      api.get(`/${c.opcionesDe.endpoint}`).then((res) => {
        if (!res.err) setOpciones((prev) => ({ ...prev, [c.name]: res.data.map((x) => x[c.opcionesDe.campo]) }));
      });
    });
  }, [entidad]);

  // CREATE
  const createData = async (data) => {
    const res = await api.post(url, data);
    if (res.err) return setAviso({ tipo: 'danger', texto: `No se pudo crear: ${res.statusText}` });
    setDb([...db, res.data]);
    setAviso({ tipo: 'success', texto: `Registro de ${entidad.singular.toLowerCase()} creado correctamente.` });
  };

  // UPDATE
  const updateData = async (data) => {
    const res = await api.put(`${url}/${data.id}`, data);
    if (res.err) return setAviso({ tipo: 'danger', texto: `No se pudo actualizar: ${res.statusText}` });
    setDb(db.map((el) => (el.id === data.id ? res.data : el)));
    setAviso({ tipo: 'success', texto: `Registro de ${entidad.singular.toLowerCase()} actualizado correctamente.` });
  };

  // DELETE (pide confirmación antes de borrar)
  const deleteData = async (id) => {
    if (!window.confirm(`¿Seguro que quieres eliminar el registro #${id}?`)) return;
    const res = await api.del(`${url}/${id}`);
    if (res.err) return setAviso({ tipo: 'danger', texto: `No se pudo eliminar: ${res.statusText}` });
    setDb(db.filter((el) => el.id !== id));
    setAviso({ tipo: 'success', texto: `Registro de ${entidad.singular.toLowerCase()} eliminado correctamente.` });
  };

  return (
    <div>
      {aviso && <Mensaje tipo={aviso.tipo} texto={aviso.texto} onCerrar={() => setAviso(null)} />}
      <CrudForm entidad={entidad} opciones={opciones} createData={createData} updateData={updateData}
        dataToEdit={dataToEdit} setDataToEdit={setDataToEdit} />
      {cargando ? <Loader /> : <CrudTable entidad={entidad} data={db} setDataToEdit={setDataToEdit} deleteData={deleteData} />}
    </div>
  );
}
