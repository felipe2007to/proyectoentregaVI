// Formulario Bootstrap que sirve para CREAR y para ACTUALIZAR.
// Los campos se construyen a partir de la configuración de la entidad (campos).
import { useEffect, useState } from 'react';

const hoy = () => new Date().toISOString().slice(0, 10);

// Formulario vacío: cada campo empieza en '' (las fechas empiezan en hoy)
const formularioVacio = (campos) =>
  Object.fromEntries(campos.map((c) => [c.name, c.type === 'date' ? hoy() : '']));

export default function CrudForm({ entidad, opciones, createData, updateData, dataToEdit, setDataToEdit }) {
  const [form, setForm] = useState(formularioVacio(entidad.campos));
  const [errores, setErrores] = useState({});

  // useEffect: cuando el usuario pulsa "Editar", dataToEdit cambia y el formulario se llena con ese registro.
  useEffect(() => {
    setForm(dataToEdit ?? formularioVacio(entidad.campos));
    setErrores({});
  }, [dataToEdit, entidad]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  // Revisa cada campo y devuelve un objeto { campo: 'mensaje de error' }
  const validar = () => {
    const e = {};
    entidad.campos.forEach((c) => {
      const valor = String(form[c.name] ?? '').trim();
      if (c.required && valor === '') e[c.name] = 'Este campo es obligatorio.';
      else if (c.type === 'number' && valor !== '' && (isNaN(valor) || Number(valor) < (c.min ?? 0))) e[c.name] = `Debe ser un número mayor o igual a ${c.min ?? 0}.`;
      else if (c.validar && valor !== '') {
        const msg = c.validar(valor);
        if (msg) e[c.name] = msg;
      }
    });
    return e;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const encontrados = validar();
    setErrores(encontrados);
    if (Object.keys(encontrados).length > 0) return; // hay errores: no se envía

    // Los campos numéricos se guardan como número, no como texto
    const datos = { ...form };
    entidad.campos.forEach((c) => { if (c.type === 'number') datos[c.name] = Number(datos[c.name]); });

    if (dataToEdit) updateData(datos); // tiene id -> ACTUALIZAR
    else createData(datos);            // no tiene id -> CREAR
    handleReset();
  };

  const handleReset = () => {
    setForm(formularioVacio(entidad.campos));
    setErrores({});
    setDataToEdit(null);
  };

  return (
    <div className="card shadow-sm mb-4">
      <div className="card-header">
        <h2 className="h5 mb-0">{dataToEdit ? `Editar ${entidad.singular}` : `Agregar ${entidad.singular}`}</h2>
      </div>
      <form className="card-body" onSubmit={handleSubmit} noValidate>
        <div className="row g-3">
          {entidad.campos.map((c) => (
            <div className="col-12 col-md-6 col-lg-4" key={c.name}>
              <label htmlFor={`campo-${c.name}`} className="form-label">
                {c.label}{c.required && <span className="text-danger"> *</span>}
              </label>

              {c.type === 'select' ? (
                <select id={`campo-${c.name}`} name={c.name} value={form[c.name] ?? ''} onChange={handleChange}
                  className={`form-select${errores[c.name] ? ' is-invalid' : ''}`}>
                  <option value="">Selecciona…</option>
                  {(c.opciones || opciones[c.name] || []).map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <input id={`campo-${c.name}`} name={c.name} type={c.type} value={form[c.name] ?? ''} onChange={handleChange}
                  min={c.type === 'number' ? c.min ?? 0 : undefined} placeholder={c.placeholder}
                  className={`form-control${errores[c.name] ? ' is-invalid' : ''}`} />
              )}

              <div className="invalid-feedback">{errores[c.name]}</div>
            </div>
          ))}
        </div>

        <div className="mt-4 d-flex gap-2">
          <button type="submit" className="btn btn-primary">{dataToEdit ? 'Guardar cambios' : 'Agregar'}</button>
          <button type="button" className="btn btn-outline-secondary" onClick={handleReset}>
            {dataToEdit ? 'Cancelar' : 'Limpiar'}
          </button>
        </div>
      </form>
    </div>
  );
}
