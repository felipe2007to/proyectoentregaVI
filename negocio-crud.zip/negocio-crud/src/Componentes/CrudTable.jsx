// Tabla Bootstrap con todos los registros. Las columnas salen de la configuración de cada entidad.
import CrudTableRow from './CrudTableRow.jsx';

export default function CrudTable({ entidad, data, setDataToEdit, deleteData }) {
  const calculados = entidad.calculados || [];

  return (
    <div className="card shadow-sm">
      <div className="card-header d-flex justify-content-between align-items-center">
        <h2 className="h5 mb-0">Listado de {entidad.titulo.toLowerCase()}</h2>
        <span className="badge text-bg-primary">{data.length} registro{data.length === 1 ? '' : 's'}</span>
      </div>
      <div className="table-responsive">
        <table className="table table-striped table-hover align-middle mb-0">
          <thead className="table-dark">
            <tr>
              <th scope="col">#</th>
              {entidad.campos.map((c) => <th scope="col" key={c.name}>{c.label}</th>)}
              {calculados.map((c) => <th scope="col" key={c.label}>{c.label}</th>)}
              <th scope="col">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {data.length === 0 ? (
              <tr>
                <td colSpan={entidad.campos.length + calculados.length + 2} className="text-center text-muted py-4">
                  No hay registros todavía. Agrega el primero con el formulario.
                </td>
              </tr>
            ) : (
              data.map((el) => (
                <CrudTableRow key={el.id} el={el} columnas={entidad.campos} calculados={calculados}
                  setDataToEdit={setDataToEdit} deleteData={deleteData} />
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
