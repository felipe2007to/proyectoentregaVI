// Alerta de Bootstrap para avisar el resultado de una acción (éxito o error).
export default function Mensaje({ tipo = 'success', texto, onCerrar }) {
  return (
    <div className={`alert alert-${tipo} alert-dismissible`} role="alert">
      {texto}
      <button type="button" className="btn-close" aria-label="Cerrar" onClick={onCerrar}></button>
    </div>
  );
}
