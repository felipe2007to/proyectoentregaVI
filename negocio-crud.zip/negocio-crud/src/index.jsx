import React from 'react';
import ReactDOM from 'react-dom/client';
import Negocio from './Negocio.jsx';

// index.jsx "encadena" la página Negocio con el index.html: React dibuja Negocio dentro del <div id="root">.
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Negocio />
  </React.StrictMode>
);
