// Validaciones con expresiones regulares. Cada función devuelve un mensaje de error,
// o una cadena vacía si el dato es correcto.

// Celular colombiano: 10 dígitos y empieza por 3
export const validarCelular = (v) => (/^3\d{9}$/.test(v) ? '' : 'El celular debe tener 10 dígitos y empezar por 3.');

// Correo: texto@dominio.extensión, sin espacios
export const validarCorreo = (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Escribe un correo válido, por ejemplo nombre@correo.com.');

// Texto con al menos 3 caracteres
export const validarTexto = (v) => (String(v).trim().length >= 3 ? '' : 'Escribe al menos 3 caracteres.');
