// HELPER DE FETCH: una función reutilizable que encapsula las peticiones HTTP.
// En vez de escribir fetch(...) con sus encabezados y su manejo de errores en cada componente,
// los componentes solo llaman: api.get('/productos'), api.post(...), api.put(...), api.del(...).
//
// Todas las funciones devuelven un objeto:
//   éxito -> { err: false, data: ... }
//   error -> { err: true, status: 404, statusText: 'Not Found' }
// Así el componente nunca se rompe: solo revisa res.err.

// La URL empieza por /api: Vite reenvía esas peticiones al puerto 5000 (json-server).
const URL_BASE = '/api';

export const helpFetch = () => {
  const customFetch = async (endpoint, options = {}) => {
    const defaultHeaders = { 'Content-Type': 'application/json' };

    // AbortController corta la petición si el servidor no responde en 5 segundos
    const controller = new AbortController();
    const tiempo = setTimeout(() => controller.abort(), 5000);

    const config = {
      ...options,
      headers: { ...defaultHeaders, ...options.headers },
      signal: controller.signal,
      // Si hay cuerpo (body), se convierte de objeto a texto JSON
      body: options.body ? JSON.stringify(options.body) : undefined,
    };

    try {
      const respuesta = await fetch(`${URL_BASE}${endpoint}`, config);
      if (!respuesta.ok) {
        return { err: true, status: respuesta.status, statusText: respuesta.statusText || 'Error en la petición' };
      }
      // DELETE devuelve un objeto vacío; por eso se lee con catch
      const data = await respuesta.json().catch(() => ({}));
      return { err: false, data };
    } catch (error) {
      const sinRespuesta = error.name === 'AbortError';
      return {
        err: true,
        status: 0,
        statusText: sinRespuesta
          ? 'El servidor tardó demasiado en responder.'
          : 'No hay conexión con la API. ¿Está encendido json-server (puerto 5000)?',
      };
    } finally {
      clearTimeout(tiempo);
    }
  };

  // Las cuatro operaciones del CRUD
  const get = (endpoint) => customFetch(endpoint);                                // READ
  const post = (endpoint, body) => customFetch(endpoint, { method: 'POST', body }); // CREATE
  const put = (endpoint, body) => customFetch(endpoint, { method: 'PUT', body });   // UPDATE
  const del = (endpoint) => customFetch(endpoint, { method: 'DELETE' });           // DELETE

  return { get, post, put, del };
};
