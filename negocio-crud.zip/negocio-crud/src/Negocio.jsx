// Negocio.jsx: la página principal. Define las 5 tablas del negocio Manantial Seguro
// (productos, clientes, proveedores, compras y ventas) y muestra el CRUD de la que se elija.
import { useState } from 'react';
import CrudAPI from './Componentes/CrudAPI.jsx';
import { validarCelular, validarCorreo, validarTexto } from './helpers/validaciones.js';

// CONFIGURACIÓN: cada entidad dice qué campos tiene. El mismo CRUD sirve para todas.
const ENTIDADES = [
  {
    clave: 'productos', titulo: 'Productos', singular: 'Producto',
    campos: [
      { name: 'nombre', label: 'Nombre', type: 'text', required: true, validar: validarTexto },
      { name: 'categoria', label: 'Categoría', type: 'select', required: true,
        opciones: ['Filtros', 'Tabletas potabilizadoras', 'Jarras', 'Dispensadores'] },
      { name: 'precio', label: 'Precio', type: 'number', required: true, min: 0, formato: 'pesos' },
      { name: 'stock', label: 'Stock', type: 'number', required: true, min: 0 },
    ],
  },
  {
    clave: 'clientes', titulo: 'Clientes', singular: 'Cliente',
    campos: [
      { name: 'nombre', label: 'Nombre completo', type: 'text', required: true, validar: validarTexto },
      { name: 'correo', label: 'Correo', type: 'email', required: true, validar: validarCorreo },
      { name: 'celular', label: 'Celular', type: 'tel', required: true, validar: validarCelular, placeholder: '3101234567' },
      { name: 'ciudad', label: 'Ciudad', type: 'text', required: true, validar: validarTexto },
    ],
  },
  {
    clave: 'proveedores', titulo: 'Proveedores', singular: 'Proveedor',
    campos: [
      { name: 'empresa', label: 'Empresa', type: 'text', required: true, validar: validarTexto },
      { name: 'contacto', label: 'Persona de contacto', type: 'text', required: true, validar: validarTexto },
      { name: 'celular', label: 'Celular', type: 'tel', required: true, validar: validarCelular, placeholder: '3101234567' },
      { name: 'suministra', label: 'Qué suministra', type: 'text', required: true, validar: validarTexto },
    ],
  },
  {
    clave: 'compras', titulo: 'Compras', singular: 'Compra',
    campos: [
      // Las listas desplegables se llenan con datos de otras tablas
      { name: 'proveedor', label: 'Proveedor', type: 'select', required: true, opcionesDe: { endpoint: 'proveedores', campo: 'empresa' } },
      { name: 'producto', label: 'Producto', type: 'select', required: true, opcionesDe: { endpoint: 'productos', campo: 'nombre' } },
      { name: 'cantidad', label: 'Cantidad', type: 'number', required: true, min: 1 },
      { name: 'costo_unitario', label: 'Costo unitario', type: 'number', required: true, min: 0, formato: 'pesos' },
      { name: 'fecha', label: 'Fecha', type: 'date', required: true },
    ],
    calculados: [{ label: 'Total', fn: (r) => r.cantidad * r.costo_unitario, formato: 'pesos' }],
  },
  {
    clave: 'ventas', titulo: 'Ventas', singular: 'Venta',
    campos: [
      { name: 'cliente', label: 'Cliente', type: 'select', required: true, opcionesDe: { endpoint: 'clientes', campo: 'nombre' } },
      { name: 'producto', label: 'Producto', type: 'select', required: true, opcionesDe: { endpoint: 'productos', campo: 'nombre' } },
      { name: 'cantidad', label: 'Cantidad', type: 'number', required: true, min: 1 },
      { name: 'precio_unitario', label: 'Precio unitario', type: 'number', required: true, min: 0, formato: 'pesos' },
      { name: 'fecha', label: 'Fecha', type: 'date', required: true },
    ],
    calculados: [{ label: 'Total', fn: (r) => r.cantidad * r.precio_unitario, formato: 'pesos' }],
  },
];

export default function Negocio() {
  const [actual, setActual] = useState(ENTIDADES[0].clave); // pestaña elegida
  const entidad = ENTIDADES.find((e) => e.clave === actual);

  return (
    <>
      <nav className="navbar navbar-dark bg-primary mb-4">
        <div className="container">
          <span className="navbar-brand mb-0 h1">
            <img src="/logo192.png" alt="" width="32" height="32" className="me-2 rounded" />
            Manantial Seguro · Gestión del negocio
          </span>
        </div>
      </nav>

      <main className="container pb-5">
        <h1 className="h3 mb-3">Panel del negocio</h1>

        {/* Pestañas de Bootstrap: una por cada tabla del negocio */}
        <ul className="nav nav-pills mb-4 flex-wrap gap-1">
          {ENTIDADES.map((e) => (
            <li className="nav-item" key={e.clave}>
              <button className={`nav-link${e.clave === actual ? ' active' : ''}`} onClick={() => setActual(e.clave)}>
                {e.titulo}
              </button>
            </li>
          ))}
        </ul>

        {/* Al cambiar la clave, React crea un CrudAPI nuevo con los datos de la otra tabla */}
        <CrudAPI key={entidad.clave} entidad={entidad} />
      </main>

      <footer className="text-center text-muted small pb-4">
        Laboratorio IV · Programación Web · Universidad Libre
      </footer>
    </>
  );
}
