# Negocio CRUD · Manantial Seguro

Laboratorio IV – Programación Web, Universidad Libre de Colombia.
CRUD en **React** que consume una **API falsa con json-server** con los datos del negocio de la tienda de filtros y purificadores de agua *Manantial Seguro*. Es el mismo CRUD que se reutiliza en el proyecto final.

## Qué incluye
- 5 tablas del negocio: **productos, clientes, proveedores, compras y ventas** (archivo `db.json`).
- CRUD completo (crear, leer, actualizar, eliminar) con `fetch` a través del helper `helpFetch`.
- Hooks `useState` y `useEffect`, validaciones de formulario, spinner de carga y alertas.
- Diseño con **Bootstrap 5** (CDN en `index.html`): navbar, pestañas, tarjetas, formulario y tabla.

## Cómo ejecutarlo (Visual Studio Code o Codespaces)
1. Abre la carpeta en VS Code y una terminal (`Ctrl + ñ`).
2. Instala las dependencias: `npm install`
3. Inicia todo: `npm start`

Esto abre **dos puertos**:

| Puerto | Qué es | Acceso |
|--------|--------|--------|
| 3000 | Página React (Vite) | Público: `http://localhost:3000` |
| 5000 | API json-server | Privado: solo la usa React mediante `/api` |

También se pueden iniciar por separado: `npm run api` (puerto 5000) y `npm run web` (puerto 3000).
En Codespaces deja el puerto 3000 como *Public*.

## Estructura
```
db.json                      Datos del negocio (API falsa)
index.html                   Estructura HTML + Bootstrap (CDN)
src/index.jsx                Punto de entrada: dibuja Negocio en #root
src/Negocio.jsx              Página principal: pestañas y configuración de las 5 entidades
src/Componentes/CrudAPI.jsx  Lógica del CRUD (useState, useEffect, create/update/delete)
src/Componentes/CrudForm.jsx Formulario de crear/editar con validación
src/Componentes/CrudTable.jsx, CrudTableRow.jsx   Tabla y filas
src/Componentes/Loader.jsx, Mensaje.jsx           Spinner y alertas
src/helpers/helpFetch.js     Helper de peticiones (get, post, put, del)
src/helpers/validaciones.js  Validaciones (celular, correo, texto)
```

## Integrantes
- _Nombre 1_
- _Nombre 2_
- _Nombre 3_

Repositorio: _pega aquí la URL de tu GitHub_
